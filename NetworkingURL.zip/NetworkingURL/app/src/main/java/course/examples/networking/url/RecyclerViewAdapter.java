package course.examples.networking.url;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import course.examples.networking.url.Country;
import course.examples.networking.url.R;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> implements Serializable {
    private final LayoutInflater layoutInflater;
    private final List<Country> countries;
    private Context context;

    public RecyclerViewAdapter(Context context, List<Country> countries) {
        this.layoutInflater = LayoutInflater.from(context);
        this.countries = countries;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View itemView = layoutInflater.inflate(R.layout.item_row, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        holder.mcountry = countries.get(position);
        //File file = new File(holder.selfie.getPathSelfieFile());
        //holder.imageView.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
        //holder.textView.setText(file.getName());
        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //openFullImage(holder.selfie.getPathSelfieFile());
            }
        });
    }

    /*
    private void openFullImage(String selfiePath) {
        Intent intentFullImage = new Intent(context, FullImage.class);
        intentFullImage.putExtra("selfiePath", selfiePath);
        String TAG = "myLogs";
        Log.d(TAG, "Path intent = " + selfiePath);
        context.startActivity(intentFullImage);
    }
    */

    @Override
    public int getItemCount() {
        return countries.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder implements Serializable {
        public final View mView;
        TextView textView;
        ImageView imageView;
        Country mcountry;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            textView = itemView.findViewById(R.id.textView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
