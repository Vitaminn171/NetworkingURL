package course.examples.networking.url;

import java.util.Locale;

public class Country {
    public String name;
    public String code;
    public String urlMapImage;

    public Country(String iName, String iCode) {
        name = iName;
        code = iCode.toLowerCase();
        urlMapImage = String.format("https://img.geonames.org/flags/x/%s.gif", code);
    }

    public Country() {

    }

    public void setCode(String iCode) {
        code = iCode.toLowerCase();
        urlMapImage = String.format("https://img.geonames.org/flags/x/%s.gif", code);
    }
}
